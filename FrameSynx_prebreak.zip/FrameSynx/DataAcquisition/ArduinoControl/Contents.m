% ARDUINOCONTROL
%
% Files
%   ArduinoInterface - Class-file defining functions for communication with
%   the Arduino Microcontroller.
%   ArduinoInterfaceDefault - Defines defaults for ArduinoInterace class
%
% See Also LEDCONTROL, FRAMESYNX