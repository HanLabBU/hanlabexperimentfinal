function filepath = imaqroot()
filepath = fileparts(which('ImageAcquisitionGUI.m'));