function [time] = hat
%HAT High Accuracy Timer
%  [TIME] = HAT uses the high-resolution performance counter to get the 
%  time which exceeds one microsecond accuracy.
