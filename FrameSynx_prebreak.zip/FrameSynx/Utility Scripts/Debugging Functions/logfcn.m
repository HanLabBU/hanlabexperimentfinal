function logfcn(src,evnt)
disp(evnt.EventName)
