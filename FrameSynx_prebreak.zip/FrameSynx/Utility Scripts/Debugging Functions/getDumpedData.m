function getDumpedData(obj,src,evnt)
dumpeddata = evnt.savedData;
assignin('base','dumpeddata')