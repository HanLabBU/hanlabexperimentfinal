function testwrite(fid,data)

fwrite(fid,data,'uint16');