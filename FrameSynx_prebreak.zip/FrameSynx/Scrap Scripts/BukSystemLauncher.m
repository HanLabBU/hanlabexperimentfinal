classdef BukSystemLauncher < hgsetget
	
	
	
	properties
		
	end
	
	
	
	
	events
		
	end
	
	
	
	
	methods
		
	end
	
	
	
	
end