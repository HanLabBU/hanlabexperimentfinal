obj = WebCameraDataGenerator;
activate(obj);



