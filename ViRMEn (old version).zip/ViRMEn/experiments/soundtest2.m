sound(8*sin(linspace(100,500,1000)),9000)
