function pathname = virmenExperimentPath()
pathname = fileparts(which('virmenExperimentPath.m'));